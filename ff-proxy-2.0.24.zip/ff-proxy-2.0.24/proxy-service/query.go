package proxyservice

import (
	"context"
	"errors"
	"fmt"

	"github.com/harness/ff-golang-server-sdk/rest"
	"github.com/harness/ff-proxy/v2/domain"
)

// QueryStore ...
type QueryStore struct {
	F            func(identifier string) (rest.FeatureConfig, error)
	S            func(identifier string) (rest.Segment, error)
	L            func() ([]rest.FeatureConfig, error)
	GetFlagMapFn func() (map[string]*rest.FeatureConfig, error)
}

// GetFlag returns a FeatureConfig from the QueryStore
func (q QueryStore) GetFlag(identifier string) (rest.FeatureConfig, error) {
	return q.F(identifier)
}

// GetSegment returns a Segment from the QueryStore
func (q QueryStore) GetSegment(identifier string) (rest.Segment, error) {
	return q.S(identifier)
}

// GetFlags returns FeatureConfigs from the QueryStore
func (q QueryStore) GetFlags() ([]rest.FeatureConfig, error) {
	return q.L()
}

// GetFlags returns FeatureConfigs from the QueryStore
func (q QueryStore) GetFlagMap() (map[string]*rest.FeatureConfig, error) {
	return q.GetFlagMapFn()
}

// GenerateQueryStore returns a QueryStore object which can be passed to the go sdk evaluator
// nolint:cyclop, gocognit
func (s Service) GenerateQueryStore(ctx context.Context, environmentID string, segments map[string]*domain.Segment) QueryStore {
	return QueryStore{
		F: func(identifier string) (rest.FeatureConfig, error) {

			// fetch feature
			flag, err := s.featureRepo.GetByIdentifier(ctx, environmentID, identifier)
			if err != nil {
				if errors.Is(err, domain.ErrCacheNotFound) {
					return rest.FeatureConfig{}, ErrNotFound
				}
				return rest.FeatureConfig{}, ErrInternal
			}

			return flag.ToSDKFeatureConfig(), nil
		},
		S: func(identifier string) (rest.Segment, error) {
			// If our segment map has been populated then lets use it
			// instead of doing a lookup in the repo. If for some reason
			// the segment doesn't exist in our map then we'll fall back
			// to hitting the repo
			if segments != nil {
				if seg, ok := segments[identifier]; ok {
					sdkSegment := seg.ToSDKSegment()
					if !s.andRulesEnabled {
						sdkSegment.ServingRules = nil
					}
					return sdkSegment, nil
				}
			}

			// fetch segment
			segment, err := s.segmentRepo.GetByIdentifier(ctx, environmentID, identifier)
			if err != nil {
				if !errors.Is(err, domain.ErrCacheNotFound) {
					return rest.Segment{}, fmt.Errorf("%w: %s", ErrInternal, err)
				}
				s.logger.Debug(ctx, "segments not found in cache: ", "err", err.Error())
			}
			sdkSegment := segment.ToSDKSegment()
			if !s.andRulesEnabled {
				sdkSegment.ServingRules = nil
			}
			return sdkSegment, nil
		},
		L: func() ([]rest.FeatureConfig, error) {
			// fetch flags
			flags, err := s.featureRepo.Get(ctx, environmentID)
			if err != nil {
				if !errors.Is(err, domain.ErrCacheNotFound) {
					return nil, fmt.Errorf("%w: %s", ErrInternal, err)
				}
				s.logger.Debug(ctx, "flags not found in cache: ", "err", err.Error())
			}
			// TODO can/should we do this conversion in the repo layer instead?
			restFlags := make([]rest.FeatureConfig, 0, len(flags))
			for _, flag := range flags {
				restFlags = append(restFlags, flag.ToSDKFeatureConfig())
			}

			return restFlags, nil
		},
		GetFlagMapFn: func() (map[string]*rest.FeatureConfig, error) {
			flags, err := s.featureRepo.Get(ctx, environmentID)
			if err != nil {
				if !errors.Is(err, domain.ErrCacheNotFound) {
					return nil, fmt.Errorf("%w: %s", ErrInternal, err)
				}
				s.logger.Debug(ctx, "flags not found in cache: ", "err", err.Error())
			}
			// TODO can/should we do this conversion in the repo layer instead?
			var flagMap = make(map[string]*rest.FeatureConfig, len(flags))

			for i := 0; i < len(flags); i++ {
				f := flags[i].ToSDKFeatureConfig()
				flagMap[f.Feature] = &f
			}

			return flagMap, nil
		},
	}
}
