# FF-Proxy
[![Go Report Card](https://goreportcard.com/badge/github.com/harness/ff-proxy)](https://goreportcard.com/report/github.com/harness/ff-proxy)

The Relay Proxy is a lightweight Go application that runs within your infrastructure and handles all streaming connections to the Harness platform. It fetches all of your flag, target, and target group data on startup, caches it, fetches any updates over time, and serves it to your connected downstream SDKs.

## Getting Started
To learn more about deploying the relay proxy see [Deploy the Relay Proxy](https://developer.harness.io/docs/feature-flags/ff-using-flags/relay-proxy/deploy-relay-proxy/).

## Why use the Relay Proxy?
To read more about use cases and advantages of the Relay Proxy see the [Why use the Relay Proxy?](https://developer.harness.io/docs/feature-flags/ff-using-flags/relay-proxy/#why-use-the-relay-proxy).

You can also read more about the use cases, architecture and more in [our blog post](https://harness.io/blog/in-depth-feature-flags-relay-proxy).


## Configuration
To view the many configuration options available read [Configuration](./docs/configuration.md).

## TLS
To view how to securely connect sdks to the Relay Proxy with HTTPS enabled see [TLS](./docs/tls.md).

## Redis Cache
By default the Relay Proxy V2 runs with a [redis cache](./docs/redis_cache.md). The Redis cache supports password authentication and mTLS (mutual TLS) authentication.

## Examples
Ready-to-run examples demonstrating various deployment scenarios:

- **[Redis mTLS](./examples/redis_mtls/)** - Redis with mutual TLS authentication (recommended for production)
- **[Redis Auth](./examples/redis_auth/)** - Redis with password authentication
- **[HA Mode with Monitoring](./examples/ha_mode_with_monitoring/)** - High availability setup with Prometheus & Grafana
- **[Redis Cluster HA](./examples/redis_cluster_ha_mode_with_monitoring/)** - Redis cluster with monitoring
- **[Load Balancing](./examples/load_balancing/)** - Nginx load balancing across multiple proxies
- **[Reverse Proxy](./examples/reverse_proxy/)** - Nginx reverse proxy setup
- **[TLS Reverse Proxy](./examples/tls_reverse_proxy/)** - HTTPS-enabled reverse proxy

## Load Balancing
For info on horizontal scaling Relay Proxies and a working example see [Load Balancing](./docs/load_balancing.md).

## Windows
If you'd like to build and run the Relay Proxy on Windows see [Windows](./docs/windows.md).

## Endpoints
For info on the external Harness SaaS endpoints the Relay Proxy communicates with see [Outbound Endpoints](./docs/outbound_endpoints.md).
For info on the Relay Proxy endpoints your sdks will connect to see [Inbound Endpoints](./docs/inbound_endpoints.md).

## Debugging
For help on debugging your Relay Proxy install see [Debugging](./docs/debugging.md).

## Contributing
See the [contribution guide](CONTRIBUTING.md).
